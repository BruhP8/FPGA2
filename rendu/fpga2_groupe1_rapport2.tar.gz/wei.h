#ifndef WEI_H
#define WEI_H
extern float Layer1_Weights_CPU[(5*5+1)*6],
Layer2_Weights_CPU[(5*5+1)*6*50],
Layer3_Weights_CPU[(5*5*50+1)*100],
Layer4_Weights_CPU[(100+1)*10];
#endif